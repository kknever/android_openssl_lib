package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {
    init {
        System.loadLibrary("myapplication")
    }
    private external fun test(csrFilePath: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val csrFilePath = File(applicationContext.filesDir, "csr22").absolutePath
        println("SSL: path: $csrFilePath")
        test(csrFilePath)
    }
}