#include <jni.h>
#include <android/log.h>
#include <iostream>

#include "myapplication.h"
#include "openssl/md5.h"
#include "zlib.h"
#include "openssl/x509.h"
#include "openssl/bn.h"
#include "openssl/bio.h"
#include "openssl/asn1.h"
#include "openssl/ecdsa.h"
#include "openssl/pem.h"
#include "openssl/rand.h"
#include "openssl/asn1t.h"

#define TAG "SSL" // 这个是自定义的LOG的标识
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__) // 定义LOGI类型
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__) // 定义LOGW类型
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__) // 定义LOGE类型
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__) // 定义LOGF类型

// RSA CSR
bool MakeCsrSSL(const  char * keyFilePath,
                const  char *email,
                const  char *name,
                const  char *country,
                const  char *saveCsrFilePath) {
    int             ret = 0;
    RSA             *r = NULL;
    BIGNUM          *bne = NULL;

    int             nVersion = 1;
    int             bits = 2048;
    unsigned long   e = RSA_F4;

    X509_REQ        *x509_req = NULL;
    X509_NAME       *x509_name = NULL;
    EVP_PKEY        *pKey = NULL;
    RSA             *tem = NULL;
    BIO             *out = NULL, *keyFileBIO = NULL;
    FILE            *pubKeyFile = NULL;

    if (strlen(saveCsrFilePath) == 0) {
//        fprintf(stderr, "MakeLocalCsrSSLApi save path is empty\n");
        LOGE("MakeLocalCsrSSLApi save path is empty");
        return false;
    }

    //not exists public key file, create one immediately.
    if (strlen(keyFilePath) == 0) {
        // 1. generate rsa key
        bne = BN_new();
        ret = BN_set_word(bne, e);
        if (ret != 1) {
//            fprintf(stderr, "MakeLocalCsrSSLApi BN_set_word err\n");
            LOGE("MakeLocalCsrSSLApi BN_set_word err");
            goto free_all;
        }

        r = RSA_new();
        ret = RSA_generate_key_ex(r, bits, bne, NULL);
        if (ret != 1) {
//            fprintf(stderr, "MakeLocalCsrSSLApi RSA_generate_key_ex err\n");
            LOGE("MakeLocalCsrSSLApi RSA_generate_key_ex err");
            goto free_all;
        }
    } else { //open it
        pubKeyFile = fopen(keyFilePath, "r");
        if (pubKeyFile == NULL) {
//            fprintf(stderr, "MakeLocalCsrSSLApi opening file %s err\n", keyFilePath);
            LOGE("MakeLocalCsrSSLApi opening file %s err\n", keyFilePath);
            goto free_all;
        }

        keyFileBIO = BIO_new_file(keyFilePath, "r");
        if (keyFileBIO == NULL) {
//            fprintf(stderr, "MakeLocalCsrSSLApi BIO_new_file err %s\n", keyFilePath);
            LOGE("MakeLocalCsrSSLApi BIO_new_file err %s\n", keyFilePath);
            goto free_all;
        }

        r = PEM_read_bio_RSAPrivateKey(keyFileBIO, NULL, NULL, NULL);
        if (r == NULL) {
//            fprintf(stderr, "MakeLocalCsrSSLApi PEM_read_bio_RSAPrivateKey err\n");
            LOGE("MakeLocalCsrSSLApi PEM_read_bio_RSAPrivateKey err\n");
            goto free_all;
        }

        /*
        //从csr文件中获取私钥
        BIO* bio = bio_open_default(csrFilePath, "r", 1);
        r = PEM_read_bio_RSAPrivateKey(bio, NULL, NULL, NULL);
        if (r == NULL) {
            fprintf(stderr, "Error PEM_read_RSAPublicKey file %s\n", savePrivateKeyFilePath);
            return false;
        }*/
    }

    // 2. set version of x509 req
    x509_req = X509_REQ_new();
    ret = X509_REQ_set_version(x509_req, nVersion);
    if (ret != 1) {
//        fprintf(stderr, "MakeLocalCsrSSLApi X509_REQ_set_version err\n");
        LOGE("MakeLocalCsrSSLApi X509_REQ_set_version err");
        goto free_all;
    }

    // 3. set subject of x509 req
    x509_name = X509_REQ_get_subject_name(x509_req); //x509_req->req_info.subject;

    ret = X509_NAME_add_entry_by_txt(x509_name, "emailAddress", MBSTRING_ASC, (const unsigned char*)email, -1, -1, 0);
    if (ret != 1) {
//        fprintf(stderr, "MakeLocalCsrSSLApi X509_NAME_add_entry_by_txt emailAddress err\n");
        LOGE("MakeLocalCsrSSLApi X509_NAME_add_entry_by_txt emailAddress err");
        goto free_all;
    }

    ret = X509_NAME_add_entry_by_txt(x509_name, "CN", MBSTRING_ASC, (const unsigned char*)name, -1, -1, 0);
    if (ret != 1) {
//        fprintf(stderr, "MakeLocalCsrSSLApi X509_NAME_add_entry_by_txt CN err\n");
        LOGE("MakeLocalCsrSSLApi X509_NAME_add_entry_by_txt CN err");
        goto free_all;
    }

//    ret = X509_NAME_add_entry_by_txt(x509_name, "C", MBSTRING_ASC, (const unsigned char*)country, -1, -1, 0);
//    if (ret != 1) {
////        fprintf(stderr, "MakeLocalCsrSSLApi X509_NAME_add_entry_by_txt C err\n");
//        LOGE("MakeLocalCsrSSLApi X509_NAME_add_entry_by_txt C err");
//        goto free_all;
//    }

    // 4. set public key of x509 req
    pKey = EVP_PKEY_new();
    EVP_PKEY_assign_RSA(pKey, r);
    r = NULL;   // will be free rsa when EVP_PKEY_free(pKey)

    ret = X509_REQ_set_pubkey(x509_req, pKey);
    if (ret != 1) {
//        fprintf(stderr, "MakeLocalCsrSSLApi X509_REQ_set_pubkey err\n");
        LOGE("MakeLocalCsrSSLApi X509_REQ_set_pubkey err");
        goto free_all;
    }

    // 5. set sign key of x509 req
    ret = X509_REQ_sign(x509_req, pKey, EVP_sha1());    // return x509_req->signature->length
    if (ret <= 0) {
//        fprintf(stderr, "MakeLocalCsrSSLApi X509_REQ_sign err\n");
        LOGE("MakeLocalCsrSSLApi X509_REQ_sign err");
        goto free_all;
    }

    out = BIO_new_file(saveCsrFilePath, "w");
    ret = PEM_write_bio_X509_REQ(out, x509_req);

    // 6. free
    free_all:
    BIO_free_all(keyFileBIO);
    X509_REQ_free(x509_req);
    BIO_free_all(out);

    EVP_PKEY_free(pKey);
    BN_free(bne);
    if (pubKeyFile) fclose(pubKeyFile);
    LOGD("MakeCsrSSL End");

    return (ret == 1);
}

// SM2 CSR
bool createCSR(const std::string& publicKeyX, const std::string& publicKeyY,
               const std::string& signatureR, const std::string& signatureS,
               const std::string& subjectDN, const std::string& csrFile) {
    EVP_PKEY* publicKey = nullptr;
    X509_REQ* req = nullptr;
    X509_NAME* name = nullptr;
    OpenSSL_add_all_algorithms();

    // 创建公钥
    publicKey = EVP_PKEY_new();
    if (publicKey == nullptr) {
        LOGE("Failed to create EVP_PKEY");
        return false;
    }

    EC_KEY* ecKey = EC_KEY_new_by_curve_name(NID_sm2);
    if (ecKey == nullptr) {
        LOGE("Failed to create EC_KEY");
        EVP_PKEY_free(publicKey);
        return false;
    }

    BIGNUM* x = BN_new();
    BIGNUM* y = BN_new();
    if (x == nullptr || y == nullptr) {
        LOGE("Failed to create BIGNUM");
        EC_KEY_free(ecKey);
        EVP_PKEY_free(publicKey);
        return false;
    }

    BN_hex2bn(&x, publicKeyX.c_str());
    BN_hex2bn(&y, publicKeyY.c_str());
    EC_POINT* point = EC_POINT_new(EC_KEY_get0_group(ecKey));
    EC_POINT_set_affine_coordinates_GFp(EC_KEY_get0_group(ecKey), point, x, y, nullptr);
    EC_KEY_set_public_key(ecKey, point);
    EVP_PKEY_assign_EC_KEY(publicKey, ecKey);

    // 创建CSR请求
    req = X509_REQ_new();
    // 设置公钥
    X509_REQ_set_pubkey(req, publicKey);

    // 设置主题信息
    name = X509_REQ_get_subject_name(req);
    X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC, (const unsigned char*)subjectDN.c_str(), -1, -1, 0);
//    X509_NAME_add_entry_by_txt(name, "emailAddress", MBSTRING_ASC, (const unsigned char*)email.c_str(), -1, -1, 0);
//    X509_NAME_add_entry_by_txt(name, "C", MBSTRING_ASC, (const unsigned char*)email.c_str(), -1, -1, 0);

    // 设置签名信息
    ASN1_INTEGER* serialNumber = ASN1_INTEGER_new();
    ASN1_INTEGER_set(serialNumber, 1);
    X509_REQ_set_version(req, 1);
    X509_REQ_set_subject_name(req, name); // 设置Subject
    X509_REQ_set_pubkey(req, publicKey);
    // 将 r 和 s 转换为字节数组
    const auto* rData = reinterpret_cast<const unsigned char*>(signatureR.c_str());
    const auto* sData = reinterpret_cast<const unsigned char*>(signatureS.c_str());
    int rLength = signatureR.length();
    int sLength = signatureS.length();

    // 创建 ASN.1 BIT STRING 对象
    ASN1_BIT_STRING* bitString = ASN1_BIT_STRING_new();
    if (bitString == nullptr) {
        // 处理内存分配错误
        X509_REQ_free(req);
        EVP_PKEY_free(publicKey);
        return false;
    }

    // 组合 r 和 s 成一个字节数组
    auto* buffer = (unsigned char*)OPENSSL_malloc(rLength + sLength);
    if (buffer == nullptr) {
        // 处理内存分配错误
        ASN1_BIT_STRING_free(bitString);
        X509_REQ_free(req);
        EVP_PKEY_free(publicKey);
        return false;
    }

    memcpy(buffer, rData, rLength);
    memcpy(buffer + rLength, sData, sLength);

    // 设置 ASN.1 BIT STRING 对象
    ASN1_BIT_STRING_set(bitString, buffer, rLength + sLength);
    X509_ALGOR* sigAlg = X509_ALGOR_new();
    X509_ALGOR_set0(sigAlg, OBJ_nid2obj(NID_sm2), V_ASN1_NULL, nullptr);
    X509_REQ_set1_signature_algo(req, sigAlg);
    // 设置 CSR 请求的签名信息
    X509_REQ_set0_signature(req, bitString);

    // 对 CSR 请求进行签名
    int signResult = X509_REQ_sign(req, publicKey, EVP_sm3());
    LOGD("signResult: %d", signResult);
//    if (X509_REQ_sign(req, publicKey, EVP_sm3()) == 0) {
//        LOGE("Failed to sign CSR");
//        X509_REQ_free(req);
//        EVP_PKEY_free(publicKey);
//        return false;
//    }

    // 将 CSR 请求写入文件
    BIO* bio = BIO_new_file(csrFile.c_str(), "w");
    if (bio == nullptr) {
        LOGE("Failed to create file BIO");
        X509_REQ_free(req);
        EVP_PKEY_free(publicKey);
        return false;
    }
    PEM_write_bio_X509_REQ(bio, req);

    // 直接打印csr，不写入文件
//    BIO *bio = BIO_new(BIO_s_mem());
//    PEM_write_bio_X509_REQ(bio, req);
//    char* csrBuffer = nullptr;
//    long csrLength = BIO_get_mem_data(bio, &csrBuffer);
//    std::string csrString(csrBuffer, csrLength);
//    LOGD("CSR Request:\n%s", csrString.c_str());

    // 释放资源
//    ASN1_BIT_STRING_free(bitString);
    OPENSSL_free(buffer);
    X509_REQ_free(req);
    EVP_PKEY_free(publicKey);
    BIO_free_all(bio);
    return true;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_myapplication_MainActivity_test(JNIEnv *env, jobject thiz, jstring csrFilePath) {
    unsigned char md5[MD5_DIGEST_LENGTH];
    std::string md5_hex;
    const char map[] = "0123456789abcdef";
    for (size_t i = 0; i < MD5_DIGEST_LENGTH; ++i) {
        std::cout << int(md5[i]) << " ";
        md5_hex += map[md5[i] / 16];
        md5_hex += map[md5[i] % 16];
    }
    LOGD("md5: %s", md5_hex.c_str());

    LOGD("openssl: %s", OpenSSL_version(OPENSSL_VERSION));

    MakeCsrSSL((const char *) "",
               (const char *) "aa@mail.com",
               (const char *) "AAName",
               (const char *) "China",
               (const char *) "/data/user/0/com.example.myapplication/files/rsa_csr");

    const char *csrFile = env->GetStringUTFChars(csrFilePath, NULL);
    std::string publicKeyX = "0000000000000000000000000000000000000000000000000000000000000000A574AA523EB54897C8C75616829467674029E31280EF5FD3C9876B5F51FC868B";
    std::string publicKeyY = "0000000000000000000000000000000000000000000000000000000000000000DEDBAC2679CF51D32A27522C43CD2F1F4A34DF2FEDABB3FBC85299691EDDA624";
    std::string signatureR = "0000000000000000000000000000000000000000000000000000000000000000FFE8DF21A585A3CFE9B153AF6D535B7F796D11DDB07F0ED773C6A894EEA929CE";
    std::string signatureS = "00000000000000000000000000000000000000000000000000000000000000009F7FA12E58930DE3D3AB673093FE811BAAA389E57FFB519D8BBD79180D332ED7";
    std::string subjectDN = "CN=China, C=CN, O=SomeOrganization, ST=Beijing, OU=SomeCompany";  // 主题信息
    if (createCSR(publicKeyX, publicKeyY, signatureR, signatureS, subjectDN, csrFile)) {
        LOGD("CSR generated successfully.");
    } else {
        LOGD("Failed to generate CSR.");
    }
    env->ReleaseStringUTFChars(csrFilePath, csrFile);
}